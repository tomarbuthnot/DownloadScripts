﻿# Powershell script to download
# all the sessions from the
# Microsoft Teched North America 2012
#
# Written by Tim Nilimaa
#
# version 1.0

$baseurl = "http://video.ch9.ms/teched/2012/na/"

$sessionlist = Get-Content c:\temp\teched\sessions.txt

$downloadDir = "c:\temp\TechEd\"

$webclient = New-Object System.Net.WebClient

$totalsessions = $sessionlist.count
$i = 0

foreach ($sessionID in $sessionlist) {
$i++
$url = $baseurl+$sessionID+".wmv"

$file = $downloadDir+$sessionID+".wmv"
write-host "Downloading session"$i" of "$totalsessions" ID: "$sessionID"..." -NoNewline
$webclient.DownloadFile($url,$file)
write-host "Done!"

}